package com.poc.webbasedspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebbasedspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebbasedspringbootApplication.class, args);
	}

}
