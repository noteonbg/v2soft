package com.poc.webbasedspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebbasedspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
